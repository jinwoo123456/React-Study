import React from "react";

function ComList(props) {
  return (
    <>
      <table id="boardTable">
        {props.myData.map((currentValue) => (
          <React.Fragment key={currentValue.no}>
            <tr>
              <td>{currentValue.no}</td>
              <td>Writer: {currentValue.writer}</td>
              <td>
                Date: {currentValue.date}
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    console.log("수정", currentValue.no);
                  }}
                >
                  수정
                </button>
                <button
                  type="button"
                  onClick={() => {
                    console.log("삭제", currentValue.no);

                    props.ComEdit.focus();
                  }}
                  onChange={(e) => {}}
                >
                  삭제
                </button>
              </td>
            </tr>
            <tr>
              <td
                colSpan="3"
                className="subject"
                style={{ whiteSpace: "pre-wrap" }}
              >
                {currentValue.comment}
              </td>
            </tr>
          </React.Fragment>
        ))}
      </table>
    </>
  );
}

export default ComList;
