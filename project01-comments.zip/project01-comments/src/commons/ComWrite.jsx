import React, { useState } from "react";

function getNowDate() {
  //작성일을 Date 객체를 통해 생성
  let dateObj = new Date();
  var year = dateObj.getFullYear(); //현재 년도
  //getMonth() : 0~11까지를 반환하므로 +1해야 현재 월을 구할 수 있음.
  var month = ("0" + (1 + dateObj.getMonth())).slice(-2);
  var day = ("0" + dateObj.getDate()).slice(-2);
  /**
   * 월과 일이 한자리인 경우에는
   * 01과 가티 설정되고
   * 두자리인 경우에는 031과 같이 문자열이 생성되므로 끝에서 두자리만 잘라낸다.
   * 따라서 0000-00-00의 포멧으로 날짜를 생성한다.
   */
  let nowDate = year + "-" + month + "-" + day;
  return nowDate;
}
function ComWrite(props) {
  let [writer, setWriter] = useState("");
  let [comment, setComment] = useState("");
  let [date, setDate] = useState("");
  let [no1, setNo] = useState(4);

  return (
    <>
      <form
        onSubmit={(event) => {
          //폼값이 전송되지 않도록 차단
          event.preventDefault();
          /**event 객체의 target 속성으로 <input>의 DOM에 접근한 후
           * 입력값을 얻어온다.
           */

          let writer = event.target.writer.value;
          let comment = event.target.comment.value;
          setNo(no1 + 1);
          let myData = {
            no: no1,
            comment: comment,
            writer: writer,
            date: getNowDate(),
          };

          props.addMyData(myData);
          console.log(myData);

          /**퀴즈 : 작성시 입력값이 없어도 등록이 되는 문제가 있으므로 빈값을
 * 검증한 후 모든 값이 입력되었을떄만 등록되도록 수정하시오
          if (title === "") {
            alert("제목을 입력해주세요");
            event.target.title.focus();
            return;
 
          }*/
          //부모 컴포넌트에서 Prop로 전달해준 함수를 호출하여 데이터를 전달한다.
        }}
      >
        <table id="boardTable">
          <tbody>
            <tr>
              <td id="writer">
                Writer :
                <input
                  type="text"
                  name="writer"
                  value={writer}
                  onChange={(e) => setWriter(e.target.value)}
                  placeholder="작성자 입력"
                  required
                />
              </td>
              <td rowSpan="2">
                <input
                  type="submit"
                  value="댓글작성"
                  id="btn"
                  onClick={(e) => {
                    console.log("Writer:", writer);
                    console.log("Comment:", comment);
                  }}
                  required
                />
              </td>
            </tr>
            <tr>
              <td>
                <textarea
                  className="abc"
                  style={{ whiteSpace: "pre-wrap" }}
                  placeholder="댓글 입력"
                  name="comment"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  required
                ></textarea>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </>
  );
}

export default ComWrite;
