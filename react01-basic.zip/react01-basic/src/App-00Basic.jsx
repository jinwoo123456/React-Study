import "./App.css";

function App() {
  return (
    <>
      <span>
        <h2>리엑트 프로젝트 기본형</h2>

        <div>안녕하세요</div>
      </span>
    </>
  );
}

export default App;
