import "./App.css";

function App() {
  return (
    <>
      <h2>리엑트 프로젝트 기본형</h2>

      <h2>React - 기본</h2>
      <ol>
        <li>프론트엔드</li>
        <ul>
          <li>html5</li>
          <li>css3</li>
          <li>javascript</li>
          <li>jquery</li>
        </ul>
        <li>백엔드</li>
        <ul>
          <li>java</li>
          <li>Oracle</li>
          <li>JSP</li>
          <li>Spring Boot</li>
        </ul>
      </ol>
    </>
  );
}

export default App;
